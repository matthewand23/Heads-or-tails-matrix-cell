// Matthew Anderson
// CSC 160 Sec 178
// 03/25/2021
// Heads and Tails matrix

import java.util.Scanner;
public class HW8matrix {

public static class Homework8 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter anumber between 0 and 511: ");
		// user input number choice
		int n = sc.nextInt();
		int bin[] = htmatrix(n); //set compiler
		
		boolean mat[][] = new boolean[3][3];
		int m = 0;
		for (int H = 0; H < 3; ++H) {//for loops to execute next number of statements
		for (int T = 0; T < 3; ++T) {//increments number after evaluated
		if (bin[m++] == 1)//binary file compiler 
		mat[H][T] = true;
		else
		mat[H][T] = false;
		}
		}
		display(mat);
		}

	public static void display(boolean mat[][]) {
		for (int H = 0; H < 3; ++H) {
		System.out.println();
		
		for (int T = 0; T < 3; ++T) {//boolean matrix cell
		
		if (mat[H][T])
		System.out.print("T" + " ");
		else
		System.out.print("H" + " ");

		}
	}
}

	public static int[] htmatrix(int n) {
		int bin[] = new int[9];
		int m = 8;
		while (n > 0) {// while loop remainder divided by 2 
		bin[m--] = n % 2;
		n = n / 2; 
		}

		return bin;

		}
	}
}